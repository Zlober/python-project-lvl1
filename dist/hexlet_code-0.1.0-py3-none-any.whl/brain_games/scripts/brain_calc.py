#!usr/bin/env python
from brain_games.engine import start_game
import brain_games.games.calc as game


def main():
    start_game(game)


if __name__ == '__main__':
    main()
